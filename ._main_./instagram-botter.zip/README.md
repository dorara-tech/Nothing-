
<div align="center">
<h1>Instagram Botter</h1>
<h3><a href="https://instagram.com">Instagram</a> followers, likes and views botter.</h3>
<br/>
<h4>By <a href="https://github.com/natrixdev">natrixdev</a> for github.</h4>
<br/>
<h1>Setup</h1>
</div>
<h2>1 - You need to install python</2>
<h4>By <a href="https://python.org/downloads">clicking here</a></h4>
<br/>
<h2>2 - Install packages</h2>
<h4>By running <a href="https://github.com/natrixdev/instagram-botter/edit/main/reqs.txt">reqs.txt</a> file</h4>
<br/>
<h2>3 - Run the botter</h2>
<h4>Run this <a href="https://github.com/natrixdev/instagram-botter/edit/main/main.py"> file</a> to access the botter</h4>
<br/>
