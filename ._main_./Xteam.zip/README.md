## Xteam tool
<br>
<p align="center">
## Screenshot:
<br>
<p align="center">
<img width="95%" src="https://github.com/xploitstech/Xteam/blob/main/Ig_information_gathering/Core_files/Xteamsce.png"\>
 
## Features:

- Insta information gathering
- Crack android lockscreen interfaces
- Phishing Hacks
- Wireless attacks added
- Update script
- Remove script
- more coming...


## Requirements
- Data connection

- No Root

## Available On
- Termux
- Kali Linux 
 
## Test On:
- Termux
- Debian 

## INSTALLATION [Termux]

* `apt update`
* `apt upgrade`
* `pkg install python`
* `pkg install python2`
* `pkg install git`
* `git clone https://github.com/xploitstech/Xteam`
* `ls`
* `cd Xteam`
* `pip3 install -r requirements.txt`
* `chmod +x *`
* `bash setup.sh`
* `bash Xteam.sh`

## INSTALLATION [Kali Linux]

* `sudo apt install python`
* `sudo apt install python2`
* `sudo apt install git`
* `git clone https://github.com/xploitstech/Xteam`
* `ls`
* `cd Xteam`
* `pip3 install -r requirements.txt`
* `chmod +x *`
* `sudo bash Xteam.sh`
  
  ### Do you want to support us?

  
  




## Warning: 
#### This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases
