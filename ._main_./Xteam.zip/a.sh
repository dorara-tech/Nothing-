nohup python /path/to/script.py > /dev/null 2>&1 & disown
