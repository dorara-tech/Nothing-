# BruteFb
HACK FACEBOOK DENGAN METODE BRUTEFORCE DI TERMUX
# Cara Install
### $ pkg update && pkg upgrade
## $ pkg install git
## $ pkg install python
## $ pip install requests
## $ pip install bs4
## $ git clone https://github.com/FR13ND8/BruteFb
## $ cd BruteFb
## $ python fb.py
# OK SEKIAN DARI GUA JANGAN LUPA KLIK BINTANG/STAR
