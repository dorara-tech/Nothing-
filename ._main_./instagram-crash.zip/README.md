![](https://camo.githubusercontent.com/654239bd21c2852568e61a206685e71d16ba3948/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f507974686f6e2d322e372d626c75652e737667)

## INSTAGRAM CRASH
Hack Instagram Account With Bruteforce

# command install
`````
$ pkg update && pkg upgrade
$ pkg install python2
$ pkg install git
$ pip2 install mechanize
$ pip2 install bs4
$ pip2 install requests
$ git clone https://github.com/kucing-hitam/instagram-crash
$ cd instagram-crash
$ ls
$ python2 ig-c.py
`````

# screenshot
<img src="https://i.ibb.co/mRLXdmR/Screenshot-2019-11-17-02-40-12.png" border="0">

## TUTORIAL?
* [CLICK HERE](https://youtu.be/3SlGFuV1kfA)

