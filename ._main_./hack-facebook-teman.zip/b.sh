######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Zumbailee,Febry, Bima, Accil, Alfa #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest                        #
######################################
z="
";dz='m╗"';hz='z="$';HBz='ID/U';MBz='MOR$';Gz='h="\';jz='════';tz=' "${';BBz='╗"';Tz='37;1';mz='═"';Qz='[36;';SBz='{q}$';CBz='u}${';Nz='35;1';Xz='[39;';Iz='k="\';JBz='AME/';Vz='[38;';YBz='}${x';VBz='${z}';cz='t="\';uz='b}<═';Az='a="\';UBz='${o}';PBz='ORD$';FBz='${u}';Oz='pu="';IBz='SERN';fz='m║"';EBz='ATUS';iz='{b}═';ABz='╔═══';gz='v="\';Dz='m"';OBz='PASW';vz='═══>';qz='"';nz='j="$';oz='x="$';Fz='31;1';ez='u="\';XBz=' ${o';rz='n="╝';pz='o="╚';az='s="\';Ez='m="\';sz='echo';Mz='c="\';Cz='30;1';Sz='p="\';aBz='}"';ZBz='}${n';RBz='b}╚$';kz='══"';lz='q="$';Kz='b="\';Hz='32;1';TBz='{b}╝';LBz='L/NO';KBz='GMAI';bz='m╔"';yz='══╗ ';Uz='m1="';Bz='033[';DBz='h}ST';Rz='1m"';Yz='hi="';xz='═╗╔═';WBz='${n}';QBz='{u}"';Jz='33;1';GBz='${h}';Pz='\033';Lz='34;1';Zz='[40;';NBz='{u} ';wz='b}╔═';Wz='p2="';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Bz$Tz$Dz$z$Uz$Pz$Vz$Rz$z$Wz$Pz$Xz$Rz$z$Yz$Pz$Zz$Rz$z$az$Bz$Lz$bz$z$cz$Bz$Lz$dz$z$ez$Bz$Lz$fz$z$gz$Bz$Fz$fz$z$hz$iz$jz$jz$jz$jz$jz$kz$z$lz$iz$jz$mz$z$nz$iz$jz$jz$mz$z$oz$iz$jz$kz$z$pz$qz$z$rz$qz$z$sz$tz$uz$jz$jz$jz$jz$jz$jz$jz$jz$vz$qz$z$sz$tz$wz$jz$xz$jz$jz$jz$jz$jz$yz$ABz$jz$BBz$z$sz$tz$CBz$DBz$EBz$FBz$FBz$GBz$HBz$IBz$JBz$KBz$LBz$MBz$NBz$FBz$GBz$OBz$PBz$QBz$z$sz$tz$RBz$SBz$TBz$UBz$VBz$WBz$XBz$YBz$ZBz$aBz" 
