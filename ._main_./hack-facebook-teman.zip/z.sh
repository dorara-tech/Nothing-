######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Zumbailee,Febry, Bima, Accil, Alfa #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest                        #
######################################
z="
";Jz='33;1';jz='mor$';dz='════';Xz='39;1';iz='l/No';Gz='h="\';kz='{m}:';Dz='m"';Zz='[40;';lz='${b}';ez='╗"';Uz='m1="';cz='b}╔═';bz=' "${';Kz='b="\';oz='╝"';Wz='p="\';az='echo';Mz='c="\';Vz='[38;';gz='${h}';Az='a="\';Sz='p1="';Ez='m="\';Bz='033[';Qz='[36;';Hz='32;1';fz='b}║ ';hz='Gmai';Iz='k="\';Cz='30;1';Oz='pu="';mz=' ║"';Yz='hi="';Rz='1m"';Fz='31;1';Nz='35;1';Tz='[37;';Lz='34;1';nz='b}╚═';Pz='\033';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Pz$Tz$Rz$z$Uz$Pz$Vz$Rz$z$Wz$Bz$Xz$Dz$z$Yz$Pz$Zz$Rz$z$az$bz$cz$dz$dz$dz$ez$z$az$bz$fz$gz$hz$iz$jz$kz$lz$mz$z$az$bz$nz$dz$dz$dz$oz$z$az" 
